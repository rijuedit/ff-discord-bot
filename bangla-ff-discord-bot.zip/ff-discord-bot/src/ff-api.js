const env = process.env;

const paths = {
  player: env.FF_PLAYER_PATH || '/player',
  duo: env.FF_DUO_PATH || '/duo',
  ban: env.FF_BAN_PATH || '/ban',
  level: env.FF_LEVEL_PATH || '/level',
  likes: env.FF_LIKES_PATH || '/likes',
};

/**
 * Generic adapter for a legitimate API provider you are authorized to use.
 * Expected request: GET {FF_API_BASE_URL}{path}?uid=PLAYER_UID
 * Optional header: Authorization: Bearer {FF_API_KEY}
 * Adapt this function to your provider's documented URL/auth/response format.
 * Never treat a missing/unknown response as a confirmed ban status.
 */
export async function fetchFFData(kind, uid) {
  const base = env.FF_API_BASE_URL?.trim();
  if (!base) {
    return { available: false, reason: 'API_NOT_CONFIGURED' };
  }

  let url;
  try {
    url = new URL(paths[kind], base.endsWith('/') ? base : `${base}/`);
  } catch {
    return { available: false, reason: 'INVALID_API_URL' };
  }
  url.searchParams.set('uid', uid);

  const headers = { Accept: 'application/json' };
  if (env.FF_API_KEY?.trim()) headers.Authorization = `Bearer ${env.FF_API_KEY.trim()}`;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 10000);
  try {
    const response = await fetch(url, { headers, signal: controller.signal });
    if (!response.ok) {
      return { available: false, reason: response.status === 404 ? 'NOT_FOUND' : `HTTP_${response.status}` };
    }
    const data = await response.json();
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
      return { available: false, reason: 'INVALID_RESPONSE' };
    }
    return { available: true, data };
  } catch (error) {
    return { available: false, reason: error.name === 'AbortError' ? 'TIMEOUT' : 'NETWORK_ERROR' };
  } finally {
    clearTimeout(timeout);
  }
}
