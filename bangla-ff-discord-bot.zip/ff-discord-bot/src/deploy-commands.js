import 'dotenv/config';
import { REST, Routes } from 'discord.js';
import { commands } from './commands.js';

const { DISCORD_TOKEN, DISCORD_CLIENT_ID, DISCORD_GUILD_ID } = process.env;
if (!DISCORD_TOKEN || !DISCORD_CLIENT_ID) {
  console.error('Set DISCORD_TOKEN and DISCORD_CLIENT_ID before registering commands.');
  process.exit(1);
}
const rest = new REST({ version: '10' }).setToken(DISCORD_TOKEN);
try {
  if (DISCORD_GUILD_ID?.trim()) {
    await rest.put(Routes.applicationGuildCommands(DISCORD_CLIENT_ID, DISCORD_GUILD_ID), { body: commands });
    console.log(`Registered ${commands.length} commands in test guild ${DISCORD_GUILD_ID}.`);
  } else {
    await rest.put(Routes.applicationCommands(DISCORD_CLIENT_ID), { body: commands });
    console.log(`Registered ${commands.length} global commands. Global commands may take time to appear.`);
  }
} catch (error) {
  console.error('Command registration failed:', error);
  process.exit(1);
}
