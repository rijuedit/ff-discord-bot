import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { fetchFFData } from './ff-api.js';

const cyan = 0x00d9ff;
const muted = 0x9ca3af;
const commands = [
  new SlashCommandBuilder().setName('player').setDescription('Look up Free Fire player information').addStringOption(o => o.setName('uid').setDescription('Player UID').setRequired(true).setMinLength(5).setMaxLength(24)),
  new SlashCommandBuilder().setName('duo').setDescription('Look up Dynamic Duo information').addStringOption(o => o.setName('uid').setDescription('Player UID').setRequired(true).setMinLength(5).setMaxLength(24)),
  new SlashCommandBuilder().setName('ban').setDescription('Check account ban status from a configured API').addStringOption(o => o.setName('uid').setDescription('Player UID').setRequired(true).setMinLength(5).setMaxLength(24)),
  new SlashCommandBuilder().setName('level').setDescription('Look up player level').addStringOption(o => o.setName('uid').setDescription('Player UID').setRequired(true).setMinLength(5).setMaxLength(24)),
  new SlashCommandBuilder().setName('likes').setDescription('Look up like statistics via configured API').addStringOption(o => o.setName('uid').setDescription('Player UID').setRequired(true).setMinLength(5).setMaxLength(24)),
  new SlashCommandBuilder().setName('help').setDescription('Show bot commands and setup status'),
  new SlashCommandBuilder().setName('ping').setDescription('Check bot latency'),
].map(c => c.toJSON());

const labels = {
  player: { title: '🎮 Free Fire Player Info', fields: [['Nickname', ['nickname', 'name']], ['UID', ['uid', 'accountId']], ['Region', ['region']], ['Level', ['level']], ['Likes', ['likes', 'likeCount']], ['Experience', ['exp', 'experience']]] },
  duo: { title: '💞 Dynamic Duo Profile', fields: [['Player', ['nickname', 'name']], ['Partner', ['partnerNickname', 'partner', 'partnerName']], ['Duo Level', ['duoLevel', 'level']], ['Intimacy Score', ['intimacyScore', 'intimacy']], ['Days Active', ['daysActive']], ['Status', ['status']]] },
  ban: { title: '🛡️ Account Security Check', fields: [['UID', ['uid', 'accountId']], ['Status', ['status', 'banStatus']], ['Checked At', ['checkedAt', 'timestamp']], ['Message', ['message', 'notice']]] },
  level: { title: '⭐ Player Level Info', fields: [['Nickname', ['nickname', 'name']], ['UID', ['uid', 'accountId']], ['Region', ['region']], ['Level', ['level']], ['Experience', ['exp', 'experience']]] },
  likes: { title: '❤️ Like Statistics', fields: [['Nickname', ['nickname', 'name']], ['UID', ['uid', 'accountId']], ['Region', ['region']], ['Before', ['before', 'likesBefore']], ['Added', ['added', 'likesAdded']], ['After', ['after', 'likesAfter']], ['Credits Left', ['creditsLeft']]] },
};

function findValue(data, keys) {
  for (const key of keys) {
    const value = data?.[key];
    if (value !== undefined && value !== null && String(value).trim() !== '') return String(value).slice(0, 1000);
  }
  return null;
}

function unavailableEmbed(uid, reason) {
  const details = {
    API_NOT_CONFIGURED: 'এই ফিচারের API এখনো সেট করা হয়নি।',
    INVALID_API_URL: 'API base URL সঠিক নয়।',
    NOT_FOUND: 'এই UID-এর জন্য API কোনো তথ্য দেয়নি।',
    INVALID_RESPONSE: 'API-এর response format বুঝতে পারিনি।',
    TIMEOUT: 'API উত্তর দিতে দেরি করেছে। পরে আবার চেষ্টা করো।',
    NETWORK_ERROR: 'API-তে সংযোগ করা যায়নি।',
  };
  return new EmbedBuilder()
    .setColor(0xf59e0b)
    .setTitle('⚠️ Data Unavailable')
    .setDescription(details[reason] || 'API অনুরোধ ব্যর্থ হয়েছে; ফলাফল নিশ্চিত করা যায়নি।')
    .addFields({ name: 'UID', value: `\`${uid}\``, inline: true }, { name: 'Status', value: 'Unverified', inline: true })
    .setFooter({ text: 'BANGLA FF PANEL • API response required' })
    .setTimestamp();
}

export async function handleCommand(interaction) {
  const name = interaction.commandName;
  if (name === 'ping') {
    return interaction.reply({ embeds: [new EmbedBuilder().setColor(cyan).setTitle('🏓 Pong!').setDescription(`WebSocket ping: **${interaction.client.ws.ping} ms**`).setTimestamp()], ephemeral: true });
  }
  if (name === 'help') {
    const apiReady = Boolean(process.env.FF_API_BASE_URL?.trim());
    const embed = new EmbedBuilder().setColor(cyan).setTitle('✨ BANGLA FF PANEL • Bot Help')
      .setDescription('Free Fire তথ্য দেখার কমান্ড')
      .addFields(
        { name: '🎮 Player', value: '`/player uid:`', inline: true },
        { name: '💞 Duo', value: '`/duo uid:`', inline: true },
        { name: '🛡️ Ban Check', value: '`/ban uid:`', inline: true },
        { name: '⭐ Level', value: '`/level uid:`', inline: true },
        { name: '❤️ Likes', value: '`/likes uid:`', inline: true },
        { name: '⚙️ API Status', value: apiReady ? 'Base URL configured; provider compatibility still needs testing.' : 'Not configured — API setup required.' },
      ).setFooter({ text: 'Only verified API data is reported.' });
    return interaction.reply({ embeds: [embed], ephemeral: true });
  }

  const uid = interaction.options.getString('uid', true).trim();
  if (!/^\d{5,24}$/.test(uid)) {
    return interaction.reply({ content: 'UID-তে শুধু ৫–২৪টি সংখ্যা দিতে হবে।', ephemeral: true });
  }
  await interaction.deferReply();
  const result = await fetchFFData(name, uid);
  if (!result.available) return interaction.editReply({ embeds: [unavailableEmbed(uid, result.reason)] });

  const config = labels[name];
  const data = result.data.data && typeof result.data.data === 'object' ? result.data.data : result.data;
  const embed = new EmbedBuilder().setColor(cyan).setTitle(config.title).setTimestamp().setFooter({ text: 'BANGLA FF PANEL • Data supplied by configured API' });
  let count = 0;
  for (const [label, keys] of config.fields) {
    const value = findValue(data, keys);
    if (value) { embed.addFields({ name: label, value, inline: true }); count++; }
  }
  if (!count) {
    return interaction.editReply({ embeds: [unavailableEmbed(uid, 'INVALID_RESPONSE')] });
  }
  if (name === 'ban') {
    const status = (findValue(data, ['status', 'banStatus']) || '').toLowerCase();
    const clearlyBanned = ['banned', 'ban', 'blocked'].includes(status);
    const clearlyNotBanned = ['not banned', 'not_banned', 'clean', 'safe'].includes(status);
    if (!clearlyBanned && !clearlyNotBanned) embed.setColor(0xf59e0b).setDescription('⚠️ API response এসেছে, কিন্তু ban status নিশ্চিতভাবে বোঝা যায়নি।');
    else embed.setColor(clearlyBanned ? 0xef4444 : 0x10b981).setDescription(clearlyBanned ? '⛔ **BANNED**' : '✅ **NOT BANNED**');
  }
  return interaction.editReply({ embeds: [embed] });
}

export { commands };
