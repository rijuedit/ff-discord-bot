# BANGLA FF PANEL — Free Fire Discord Bot (Starter)

JavaScript / Node.js / discord.js v14 starter for GitHub + Render.

## Included slash commands
- `/player uid:` — player profile fields returned by your configured API
- `/duo uid:` — dynamic duo fields returned by your configured API
- `/ban uid:` — reports ban status only when the API response clearly identifies it
- `/level uid:` — level/experience fields returned by your API
- `/likes uid:` — reads like statistics from your API; it does not automate likes by itself
- `/help`, `/ping`

## Important API limitation
This repository does **not** include a made-up or unverified Free Fire API. The API adapter currently expects a provider that supports these documented routes (customize paths in environment variables):

- `GET {base}/player?uid=123456`
- `GET {base}/duo?uid=123456`
- `GET {base}/ban?uid=123456`
- `GET {base}/level?uid=123456`
- `GET {base}/likes?uid=123456`

It optionally sends `Authorization: Bearer <FF_API_KEY>`. You must adapt `src/ff-api.js` to the actual provider's documentation, authentication and response format. The bot recognizes common field names, but different providers may need mapping changes in `src/commands.js`. Blank API configuration returns an explicit unavailable response rather than fake results.

Use only an API you are authorized to access. Do not submit player passwords, session tokens or account credentials. `/likes` is a statistics lookup, not a tool for unauthorized automated engagement or game manipulation.

## 1. Create a Discord application
1. Open https://discord.com/developers/applications and click **New Application**.
2. Open **Bot** and create/reset a bot token. Keep it secret.
3. Open **OAuth2 > URL Generator**; select scopes `bot` and `applications.commands`.
4. Invite the bot to your server. It only needs basic view/send message and embed permissions for these commands.
5. Copy the Application ID from **General Information**. Enable Developer Mode in Discord and copy your test server ID.

## 2. Push to GitHub
1. Download and unzip this project.
2. Create a new empty repository at https://github.com/new.
3. Upload the extracted files (including `src/`) to the repository root. Do not upload `.env` or your bot token.
4. In your local project folder, copy `.env.example` to `.env` and fill in your credentials for local testing.
5. Install Node.js 22, then run:

```bash
npm install
npm run deploy-commands
npm start
```

For a quick web-free GitHub upload, use **Add file > Upload files** in your new repository and drag in the project files. Make sure hidden files such as `.gitignore` are included if your browser permits it.

## 3. Deploy on Render
1. Open https://dashboard.render.com/ and connect GitHub.
2. Choose **New + > Background Worker** and select this repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add Environment Variables:
   - `DISCORD_TOKEN` = bot token
   - `DISCORD_CLIENT_ID` = Application ID
   - `DISCORD_GUILD_ID` = test server ID (optional but recommended during testing)
   - `FF_API_BASE_URL` = your legitimate API base URL (leave blank until found)
   - `FF_API_KEY` = API key, if provider requires it
   - Optional route overrides: `FF_PLAYER_PATH`, `FF_DUO_PATH`, `FF_BAN_PATH`, `FF_LEVEL_PATH`, `FF_LIKES_PATH`
6. Deploy. The worker starts the bot. Check Render logs for `Logged in as ...`.
7. Register slash commands from your computer once: `npm run deploy-commands`. This uses the same Discord token, application ID and optional guild ID in your local `.env`. If you switch to global commands, remove `DISCORD_GUILD_ID` and run it again.

## Render cost / uptime
A Discord Gateway bot needs a continuously running worker. Render's free web service is not the right service type for a persistent bot worker; check Render's current pricing before creating a worker. The included `render.yaml` uses a paid `starter` worker as an explicit deployment target. Do not assume free 24/7 uptime.

## API response example (format illustration only)
This is a **sample response schema**, not a real API endpoint or real player data:

```json
{
  "nickname": "ExamplePlayer",
  "uid": "123456789",
  "region": "BD",
  "level": 55,
  "likes": 1200,
  "exp": 500000
}
```

## Troubleshooting
- `Used disallowed intents`: this starter only requests Guilds intent; do not enable privileged intents unless you add a feature that needs them.
- Slash commands missing: check `DISCORD_CLIENT_ID`, `DISCORD_GUILD_ID`, bot invite scopes, then run `npm run deploy-commands` again.
- `API_NOT_CONFIGURED`: normal until you configure a legitimate provider.
- API gives 401/403: verify the API key/auth method and edit `src/ff-api.js` to match provider docs.
- Fields missing: adapt the field mapping in `src/commands.js` to the provider's JSON response.
